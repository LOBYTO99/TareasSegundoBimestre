
package newpackage;

import java.util.Scanner;

public class Pruebajuego {
    public static void main(String[]args){
        Scanner teclado = new Scanner(System.in);
        Juego puntajemayor = new Juego();
        puntajemayor.menu();
        /*juego1.inicializaciones();
        juego1.registrarjugadores();
        juego1.jugar();*/
    }
}
